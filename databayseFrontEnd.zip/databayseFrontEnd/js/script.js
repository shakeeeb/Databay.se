$(document).ready(function(){
     $("#sell").carousel({
         interval : false
     });
});
</script>

